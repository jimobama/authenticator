

var ModalContext =Object.extends(Context, function(id,options){
  //settings defaults for modal
   var __options  = Object.copy({raise:true,"closebutton":true}, options);
   Context.call(this,"div", __options);

	 var cxt = new Context(id, __options);


   var onBtnClose =(function(e){
       this.domElement.style.display="none";
       this.domElement.remove();
    }).bind(this);
   var onBtnHover=(function(e){
      

   });

	var createCloseButton =(function(cxt){
    if(this.options.closebutton !=true)return ;
		 var closeBtn = document.createElement("span");
		  closeBtn.classList.add("modal-close-button");
		  this.domElement.insertBefore(closeBtn, cxt.domElement);
		  this.attachEventTo(closeBtn, "click", onBtnClose);
		  this.attachEventTo(closeBtn, "mouseover", onBtnHover);
	}).bind(this);

	var onInit=(function(){
	     cxt.addClass("container")
       this.setContextPane(cxt);
       if(this.options)
       createCloseButton(cxt);
       this.addClass("modal-context");
       document.body.appendChild(this.domElement);
       cxt.center(this);
       Object.defineProperties(this, {"modalContext":{value:cxt,writable:false, enumerable:false}});
	}).bind(this)();
})

ModalContext.prototype.getModalContext=(function(){
   return this.modalContext;
});
