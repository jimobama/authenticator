/*
  The context is the primary view array of the framework

*/


var Context = Object.extends(null, function(domID, arg_options){
  
var initOptions = (function(options){
         // default settings here       
      var __options = Object.copy({
        raise:false,
        dragable:false,
        "responsive":false
      }, options);
      return __options;
});

var setSettings=(function(options){
       if(!options)return;
       if(this.domElement){
         this.addClass("context");
         if(options.raise==true)
           this.addClass("raise");         
       }
}).bind(this);



var  addContextListener=(function(eventtype){
    var isString =(typeof eventtype =="string");
    if(isString){
    if(window.addEventListener){
      window.addEventListener(eventtype, this.invalidated.bind(this), false);
   }
    else if(window.attachEvent)
      window.attachEvent("on"+eventtype, this.invalidated.bind(this), false);
    }
}).bind(this);


var initContext =(function(options){        
        var element =   Context.create(domID);  

        if(element){
          Object.defineProperties(this, {"domElement":{value:element,writable:false,enumerable:true}}); 
          var options = initOptions(options);                     if(options)
               Object.defineProperties(this, {"options":{value:options,writable:false,enumerable:true}});
          setSettings(options);    
          if(this.options.responsive==true){
          addContextListener("resize");
          addContextListener("scroll")
         }
        }
}).bind(this)(arg_options);
     
});

Context.create=(function(idOrElement){
  var element =null;   
  if(idOrElement){    
     if(typeof idOrElement==='string'){
       element=  Context.fromString(idOrElement);
     }else if(idOrElement instanceof HTMLElement)
       element = idOrElement;
      else
        throw TypeError("@Invalid parameter id provided , required a string value");
  }
 return element;
});
Context.fromString=(function(stringId){
  var element =null;
  if(typeof stringId==='string' && stringId !==""){
     element = document.getElementById(stringId);
     if(!element)
           element = document.createElement(stringId);
  }
 return element;
});

Context.prototype.html=(function(html /*get or set innerHTML*/){
 if(this.domElement){
   if(!html)return this.domElement.innerHTML;
    this.domElement.innerHTML = html;  
 }
});
Context.prototype.value=(function(value/*get or set innerHTML*/){
 if(this.domElement){
   if(!html)return this.domElement.value;
    this.domElement.value = value;  
 }
});

Context.prototype.setContextPane=(function(panelOrDom){
  this.html("");
  if(panelOrDom instanceof Context){
     this.domElement.appendChild(panelOrDom.domElement);
    }
  else if(panelOrDom instanceof HTMLElement){
    this.domElement.appendChild(panelOrDom);
  }else{
     throw TypeError("@setContextPane require either domElement or a Context Object");
  }
})

Context.prototype.pack=(function(){
   if(this.domElement){
      this.addClass("wrap-content");
   }
   return this;
});
Context.prototype.setVisible=(function(abool){
  var isbool = (abool==true)?true:false;
  this.addClass("hide");
})
Context.prototype.addClass=(function(classname){
  
  if(this.domElement){
    this.addClassTo(this.domElement, classname);
  }
  return this;
});

Context.prototype.addClassTo=(function(element, classname){
  if(typeof classname !=="string") return; 
  var isType = (element instanceof HTMLElement);

  if(isType){
     if(!element.classList.contains(classname))
          element.classList.add(classname);
  }
  return this;
});


Context.prototype.onEvent=(function(eventtype, callback){
      if(typeof eventtype!=="string")return;
      if(!Object.isCallable(callback))return ;
      this.attachEventTo(this.domElement,eventtype, callback);
    return this;
});

Context.getScreenSize =(function(){
  var sWidth =  window.screen.availWidth ;
  var sHeight = window.screen.availHeight;
  return {
     "width":sWidth,
     "height":sHeight,
     "x":0,
     "y":0
  }
});
Context.prototype.getRect=(function(){
  return this.domElement.getBoundingClientRect();
})

Context.prototype.center=(function(domOrCentext){
 var rect = null;
  if(domOrCentext instanceof HTMLElement)
     rect =domOrCentext.getBoundingClientRect();
   else if (domOrCentext instanceof Context){
     rect = domOrCentext.domElement.getBoundingClientRect();
   }
  else{
    rect = Context.getScreenSize();
  }
  var selfRect = this.getRect();
  var xPos = ((rect.width + rect.left) - (selfRect.width + selfRect.left))   * 0.5;
  var yPos = ((rect.height + rect.top) - (selfRect.height + selfRect.top))  * 0.5;
  this.domElement.style.left= xPos +"px";
  this.domElement.style.top= yPos +"px";
  return this;
});

Context.prototype.invalidated =(function()
{
   this.center();

});
Context.prototype.attachEventTo =(function(element, eventtype, callback)
{
    if(typeof eventtype!=="string")return this;
      if(!Object.isCallable(callback))return this;
       if(element){
          if(element.addEventListener){
                    element.addEventListener(eventtype,callback,false);
          }else if(element.attachEvent){
                  element.attachEvent(+"on"+eventtype,callback);
          }
      }
 return this;
});



Context.prototype.directTags=(function(element, tag){
var result = new  Array();
var nodes = element.childNodes;
if(!nodes && nodes.length <=0)return result;
if(typeof tag ==='string'){
  Array.from(nodes).map(function(element){
    if(element.tagName){
     var temTag =element.tagName.toString().toLowerCase();
          if(tag === temTag){
            result.push(element);
          }
        }
       });
}
return result;
});





