/** @extends _function
    This function implements a deep inheritance in javascript and also provided muliple inheritances

   

**/

Object.extends=(function(constructor,...parents){ 
  var __construct=constructor;
 if(!Object.isCallable(__construct)){
     __construct =(function(){});
  }
 var typeclass=__construct;
  if(parents){
      parents.forEach(function(p){
         typeclass  = Object.extend(typeclass, p);
         typeclass.prototype.constructor =  typeclass;

      })
  }


  return typeclass;
});

//simple inheritances
Object.extend =(function(constructor, parent){
  var __construct =constructor || (function(){});
  var __super = (function(self, ...args){});
  var __isClass =(function(aclass){return (typeof aclass ==="function"); });
  var __subclass  = __construct;

  var __container=(function(){
     var arr=new Array();
     arr.contains=(function(classobj){
        for(var i=0; i < this.length ; i++){
          var base = this[i]; 
           var jsonBase =JSON.stringify(base.prototype);
           var jsonComp =JSON.stringify(classobj.prototype);
          if(jsonBase ===jsonComp) return true;
        }
        return false;
     }).bind(arr);

     return arr;
  });
  //check to make sure is a function object
  if(Object.isCallable(parent)){
     __subclass = Object.clone(parent,__subclass);
     __subclass.prototype = Object.create(parent.prototype);
     __subclass.prototype.constructor =  __construct;
  }
  if(!__subclass.prototype.__bases)
      Object.defineProperties(__subclass.prototype, {"__bases":{value:__container(),writable:false, enumerable:true}});
  __subclass.prototype.__bases.push(parent);
 return __subclass;
});



Object.isCallable =(function(aclass){return (typeof aclass ==="function"); });

Object.prototype.instanceOf = (function(aclassobj){
  if(!aclassobj)return false;
  if(Object.isCallable(aclassobj)){
     return  this.__bases.contains(aclassobj);
   }
   return false;
 });

Object.clone =(function(source, destination){
 if(!destination)var destination={};
    if(!source)var source={};
    for(var attri in source ){
        if(typeof source[attri] == 'object'){
          destination[attri] = (source[attri] instanceof Array )?[]:{};
          destination[attri] = clone(source[attri], destination[attri]);
        }else{
          if(!destination.hasOwnProperty(attri)){
            destination[attri] = source[attri];
          }
              
        }
      }
     return destination;
});

