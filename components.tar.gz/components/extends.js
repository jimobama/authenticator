/** @extends _function
    @isCallable
    @clone 

    This are addition helper functions to the native js Object function
**/

Object.extends =(function(parent, constructor){
  var __construct = constructor || (function(){});
  var __subclass  = __construct;
  if(!Object.isCallable(parent))return __subclass;
  __subclass = Object.copy(parent,__subclass);
  __subclass.prototype = Object.create(parent.prototype);
  __subclass.prototype.constructor =  __construct;
 return __subclass;
});


/*@Check if a function is callable or not */
Object.isCallable =(function(aclass){return (typeof aclass ==="function"); });
/*@Check if a object is an instanceof */
Object.prototype.instanceOf = (function(aclassobj){
  if(!aclassobj || !Object.isCallable(aclassobj))return false;
   return (this instanceof aclassobj);
 });

/*Copy object or function direct members*/
Object.copy =(function(source, dest){
 if(!dest)var dest={};
 if(!source)var source={};
 for(var member in source ){
   if(typeof source[member] == 'object'){
          dest[member] = (source[member] instanceof Array )?[]:{};
          dest[member] = Object.copy(source[member], dest[member]);
   }else{
     if(!dest.hasOwnProperty(member)){
         dest[member]  =  source[member];         
        }
      }
  }//end while

 return dest;
});

