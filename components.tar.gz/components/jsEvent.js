 /*Event Handler
  Support for both backward and new broswer
  */

  var JsEvent =(function(event, data)
  {
  	if(typeof this ==='function')
  		throw new Error("JsEvent have to vbe constructed with the new statment");
  	var __event={};
          //an inner constructor 
          var onInit=(function(aevent, adata){
          	isString =(typeof aevent==='string');
          	if(!adata  && (typeof adata !=='object'))
          		adata=={};
          	if(!isString)return ;
          	if(Event){
          		__event = new Event(aevent,{"bubbles":true,"cancelable":false,"details":adata});
          	}else{
          		__event = document.createEvent("Event");
          		__event.initEvent(aevent,true,false);
          	}
          	if(__event){
          		Object.defineProperties(this, {"event":{value:__event,writable:false, enumerable:false},
          			"name":{value:aevent,writable:false, enumerable:true}})
          	}
          }).bind(this)(event, data);
      });


  JsEvent.prototype.emit=(function(element){
  	if(element)
  		if(element.dispatchEvent){
  			element.dispatchEvent(this.event);
  		}else if(element.fireEvent){
  			element.fireEvent("on"+this.name, this.event);
  		}else{
  			throw new Error("Event element does not support event addEventListener");
  		}
  	});

  

