var MenuItem=Object.extends(Context, function(domId, options){
	var __options = Object.copy({"raise":false},options);
	Context.call(domId,__options);
	var onInit=(function(){
	  if(this.domElement){
	  	 this.addClass("menu-item");
	  }
	}).bind(this)();

});
MenuItem.prototype.setIcon =(function(url){
  if(typeof url ==='string'){
  	 this.domElement.style.backgroundImage=url;
  }
});


