/*
  The menu  


*/
var MenuItem=Object.extends(Context, function(domId, options){
	var onInit=(function(Id, options){
	  var domElement =	Context.create(Id);
	  if(domElement){
	  	 
	  }

	}).bind(this)(domId, options);

});



var Menu =Object.extends(Context,(function(domId, options)
{
  var __options = Object.copy({

  }, options);
  Context.call(this, domId, __options);
  if(this.options){
  	 this.addClass("menu");
  	 this.reflow(this.domElement);
  }
 
}));
Menu.prototype.getElementIfEqual=(function(domId, nodes){
if(!nodes && nodes.length <=0)return null;
var element=null;
for(var i=0; i< nodes.length; i++){
	element = nodes[i];
    if(element.id ===domId)
    	break;
     if(element.childNodes && element.childNodes.length>0){
     	element = this.getElementIfEqual(domId,element.childNodes );
     	if(element)break;
     }
  }
  return element;
});
Menu.prototype.attachMenuTitle =(function(domId){
   if(this.domElement && (typeof domId==='string')){
   	 var childrens =  this.domElement.childNodes;
   	 var headerEl = this.getElementIfEqual(domId, childrens);
   	 if( headerEl instanceof HTMLElement){
   	 	Object.defineProperties(this,{"title":{value:headerEl, writable:false, enumerable:true}});
   	 }
   }
   return this;
});

Menu.prototype.setTitle=(function(strTitle){

   if(this.title){
   	 this.title.innerHTML=="";
   	 if(typeof strTitle==="string"){
       this.title.innerHTML=strTitle;
   	 }
   }
   return this;
})
Menu.prototype.attachTo=(function(element){
 if(element instanceof HTMLElement){

 }

});

Menu.prototype.directTags=(function(element, tag){
var result = new  Array();
var nodes = element.childNodes;
if(!nodes && nodes.length <=0)return result;
if(typeof tag ==='string'){
	Array.from(nodes).map(function(element){
		if(element.tagName){
		 var temTag =element.tagName.toString().toLowerCase();
          if(tag === temTag){
            result.push(element);
          }
        }
       });
}
return result;
});



Menu.prototype.reflow=(function(element){
	
	return this;
});




