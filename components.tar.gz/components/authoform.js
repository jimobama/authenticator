var AuthoForm =Object.extends(ModalContext,(function(domId, options){

	  ModalContext.call(this, domId,options);
	  this.addClass("autho");
}));

