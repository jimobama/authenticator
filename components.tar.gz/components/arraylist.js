
var ArrayList = Object.extends(Array, (function(anarray){
   var array = (anarray instanceof Array)?anarray:[];
   Array.call(this, array);

}));
ArrayList.prototype.contains =(function(item, compare){
var comp = (Object.isCallable(compare))?compare : (function(a,b){return a===b;});
for(var i=0; i < this.length ; i++){
          var base = this[i]; 
          if(comp(item, base)) return true;
    }
   return false;
});

ArrayList.prototype.remove =(function(item, compare){
var comp = (Object.isCallable(compare))?compare : (function(a,b){return a===b;});
 for(var i=0; i < this.length ; i++){
          var base = this[i]; 
          if(comp(item, base)){
          	return  this.splice(i, 1);
      };
    }
   return false;
});
ArrayList.prototype.add =(function(item){
  if(item !=null){
  	 this.unshift(item);
  }
});


